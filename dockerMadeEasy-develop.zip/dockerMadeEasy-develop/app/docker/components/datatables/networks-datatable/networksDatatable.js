angular.module('dockerMadeEasy.docker').component('networksDatatable', {
  templateUrl: 'app/docker/components/datatables/networks-datatable/networksDatatable.html',
  controller: 'GenericDatatableController',
  bindings: {
    title: '@',
    titleIcon: '@',
    dataset: '<',
    tableKey: '@',
    orderBy: '@',
    reverseOrder: '<',
    showTextFilter: '<',
    showOwnershipColumn: '<',
    removeAction: '<'
  }
});
