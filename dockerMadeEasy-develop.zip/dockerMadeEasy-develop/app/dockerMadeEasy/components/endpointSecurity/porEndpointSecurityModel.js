function EndpointSecurityFormData() {
  this.TLS = false;
  this.TLSMode = 'tls_client_ca';
  this.TLSCACert = null;
  this.TLSCert = null;
  this.TLSKey = null;
}
