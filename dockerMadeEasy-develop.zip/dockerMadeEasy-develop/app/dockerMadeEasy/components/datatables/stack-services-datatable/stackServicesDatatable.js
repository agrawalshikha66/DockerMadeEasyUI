angular.module('dockerMadeEasy.app').component('stackServicesDatatable', {
  templateUrl: 'app/dockerMadeEasy/components/datatables/stack-services-datatable/stackServicesDatatable.html',
  controller: 'GenericDatatableController',
  bindings: {
    title: '@',
    titleIcon: '@',
    dataset: '<',
    tableKey: '@',
    orderBy: '@',
    reverseOrder: '<',
    nodes: '<',
    publicUrl: '<',
    showTextFilter: '<'
  }
});
