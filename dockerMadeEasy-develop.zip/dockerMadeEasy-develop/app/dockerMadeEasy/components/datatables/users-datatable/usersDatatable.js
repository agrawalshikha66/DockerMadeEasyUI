angular.module('dockerMadeEasy.app').component('usersDatatable', {
  templateUrl: 'app/dockerMadeEasy/components/datatables/users-datatable/usersDatatable.html',
  controller: 'GenericDatatableController',
  bindings: {
    title: '@',
    titleIcon: '@',
    dataset: '<',
    tableKey: '@',
    orderBy: '@',
    reverseOrder: '<',
    showTextFilter: '<',
    removeAction: '<',
    authenticationMethod: '<'
  }
});
