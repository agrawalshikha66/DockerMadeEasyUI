angular.module('dockerMadeEasy.app').component('slider', {
  templateUrl: 'app/dockerMadeEasy/components/slider/slider.html',
  controller: 'SliderController',
  bindings: {
    model: '=',
    onChange: '&',
    floor: '<',
    ceil: '<',
    step: '<',
    precision: '<'
  }
});
