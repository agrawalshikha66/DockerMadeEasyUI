angular.module('dockerMadeEasy.app').component('codeEditor', {
  templateUrl: 'app/dockerMadeEasy/components/code-editor/codeEditor.html',
  controller: 'CodeEditorController',
  bindings: {
    identifier: '@',
    placeholder: '@',
    yml: '<',
    readOnly: '<',
    onChange: '<',
    value: '<'
  }
});
